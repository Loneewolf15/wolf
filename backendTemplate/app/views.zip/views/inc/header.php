<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="<?php echo URLROOT; ?>/asset/css/style.css">
  <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"> -->
 
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css"> 
  <title><?php echo SITENAME; ?></title>
</head>
<body>
<?php require APPROOT . '/views/inc/navbar.php'; ?>
  <div class="container-fluid">
    <br>
    <br>
   
    