<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Veluxpay</title>
</head>
<body style="background-color:black">
 <div class="email" style="max-width: 600px; min-width: 200px; background-color: blanchedalmond; padding: 20px; margin: auto;">
 <h1>hello hello </h1>
    <h2>hello hello </h2>
 </div>
</body>
</html>